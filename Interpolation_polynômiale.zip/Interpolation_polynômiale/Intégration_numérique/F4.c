#include<stdio.h>

double F4(double x)
{
    return 4/(1+x*x);
}

