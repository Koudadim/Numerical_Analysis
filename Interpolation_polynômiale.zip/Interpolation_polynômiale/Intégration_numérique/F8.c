#include<stdio.h>
#include<math.h>

double F8(double x)
{
    return x*exp(-x);
}

