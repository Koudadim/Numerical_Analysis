#include<stdio.h>

double F2(double x)
{
    return 1/x;
}
