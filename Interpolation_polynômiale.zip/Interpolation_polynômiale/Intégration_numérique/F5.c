#include<stdio.h>

double F5(double x)
{
    return x/(1+x*x);
}

