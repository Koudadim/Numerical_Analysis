#include <stdio.h>
#include <math.h>
double F2(double x)
{
    return sin(x)/(2+cos(x));
}
