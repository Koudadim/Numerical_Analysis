#include <stdio.h>
#include <math.h>
double F4(double x)
{
    return 1/cos(x);
}

