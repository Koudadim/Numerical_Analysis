#include <stdio.h>
#include <math.h>
double F3(double x)
{
    return x+exp(-x);
}
