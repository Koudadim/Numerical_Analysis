#include <stdio.h>
#include <math.h>
double F1(double x)
{
    return sin(x)+x;
}
