#include <stdio.h>
#include <math.h>
double F5(double x)
{
    return log(1+x*x);
}


