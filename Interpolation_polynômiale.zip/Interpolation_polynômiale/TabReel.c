#include <stdio.h>
#include <stdlib.h>

double* TabReel(int n)
{
    int i;
    double *t;
    double* TabDouble(int N);
    t=TabDouble(n+1);
    for(i=1; i<=n+1; i++)
        scanf("%lf", t+i);
    return t;
}

