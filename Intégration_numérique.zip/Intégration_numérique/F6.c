#include<stdio.h>

double F6(double x)
{
    return 1/(7-2*x);
}

