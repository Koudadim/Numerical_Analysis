#include<stdio.h>
#include<math.h>

double F7(double x)
{
    return log(fabs(x));
}

