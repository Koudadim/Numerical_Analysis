#include<iostream>

using namespace std;

void Tracer()
{
     cout<<endl<<endl;
	cout<<"************=============================================****************";
	cout<<endl<<endl;
}
