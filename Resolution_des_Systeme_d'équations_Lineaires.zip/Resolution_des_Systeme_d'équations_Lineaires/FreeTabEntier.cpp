#include<iostream>

void FreeTabEntier(int* T)
{
	delete [] T;
}

