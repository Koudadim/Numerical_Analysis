#include<iostream>

void FreeTabReel(double* T)
{
	delete [] T;
}
