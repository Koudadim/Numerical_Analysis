#include<stdio.h>
#include<math.h>

double f3nde(double x)
{
    return (24*x*x-8)/((x*x+1)*(x*x+1)*(x*x+1))+10*cos(x);
}
