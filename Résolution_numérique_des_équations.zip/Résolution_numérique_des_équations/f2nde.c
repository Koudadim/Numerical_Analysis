#include<stdio.h>
#include<math.h>

double f2nde(double x)
{
    return -2+x/(sqrt(x*x+1));
}
