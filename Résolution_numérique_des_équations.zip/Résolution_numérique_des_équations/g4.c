#include<stdio.h>
#include<math.h>

double g4(double x)
{
    return sqrt(4-2*log(x*x+1));
}


