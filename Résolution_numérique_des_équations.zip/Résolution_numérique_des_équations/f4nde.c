#include<stdio.h>
#include<math.h>

double f4nde(double x)
{
    return (x*x*x*x+3)/((x*x+1)*(x*x+1));
}
