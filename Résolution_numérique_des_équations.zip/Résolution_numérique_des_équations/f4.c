#include<stdio.h>
#include<math.h>

double f4(double x)
{
    return log(x*x+1)+x*x/2 -2;
}
