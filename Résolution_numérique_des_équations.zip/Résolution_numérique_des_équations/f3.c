#include<stdio.h>
#include<math.h>

double f3(double x)
{
    return 4/(x*x+1)-10*cos(x);
}
