#include<stdio.h>
#include<math.h>

double g1(double x) //Fonction iterante de sinx/x=0
{
    double f1(double x);
    return x-4*f1(x);
}
