#include<stdio.h>
#include<math.h>

double f1(double x)
{
    return  sin(x)/x;
}
