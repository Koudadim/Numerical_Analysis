#include<stdio.h>
#include<math.h>

double f1nde(double x)
{
    return ((2-x*x)*sin(x)-2*x*cos(x))/(x*x*x);
}
