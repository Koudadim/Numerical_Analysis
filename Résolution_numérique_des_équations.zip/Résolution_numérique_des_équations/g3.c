#include<stdio.h>
#include<math.h>

double g3(double x)
{
    return acos(2/(5*(x*x+1)));
}

