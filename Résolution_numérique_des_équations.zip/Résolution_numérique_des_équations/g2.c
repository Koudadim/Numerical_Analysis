#include<stdio.h>
#include<math.h>

double g2(double x)
{
    return (sqrt(x*x+1))/2;
}
